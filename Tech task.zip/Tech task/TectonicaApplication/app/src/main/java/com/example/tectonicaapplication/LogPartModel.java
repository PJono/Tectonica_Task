package com.example.tectonicaapplication;

public class LogPartModel {
    private int jobNumber;
    private String serialNumber;
    private int partNumber;
    private String operatorName;
    private boolean outcome;

    public LogPartModel(int jobNumber, int partNumber, String serialNumber, String operatorName, boolean outcome) {
        this.jobNumber = jobNumber;
        this.serialNumber = serialNumber;
        this.partNumber = partNumber;
        this.operatorName = operatorName;
        this.outcome = outcome;
    }

    public LogPartModel() {
    }

    @Override
    public String toString() {
        return "LogData{" +
                "Job=" + jobNumber +
                ", Serial='" + partNumber + '\'' +
                ", Part=" + serialNumber +
                ", Operator=" + operatorName +
                ", Outcome=" + outcome +
                '}';
    }

    //getters and setters
    public int getJobNumber() {
        return jobNumber;
    }

    public void setJobNumber(int jobNumber) {
        this.jobNumber = jobNumber;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public int getPartNumber() {
        return partNumber;
    }

    public void setPartNumber(int partNumber) {
        this.partNumber = partNumber;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public boolean isOutcome() {
        return outcome;
    }

    public void setOutcome(boolean outcome) {
        this.outcome = outcome;
    }
}
