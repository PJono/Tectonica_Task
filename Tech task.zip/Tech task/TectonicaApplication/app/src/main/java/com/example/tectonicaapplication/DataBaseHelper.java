package com.example.tectonicaapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DataBaseHelper extends SQLiteOpenHelper {
    public static final String LOG_PART_TABLE = "LOG_PART_TABLE";
    public static final String COLUMN_JOB_NUMBER = "JOB_NUMBER";
    public static final String COLUMN_LOG_PART_SERIAL = "LOG_PART_SERIAL";
    public static final String COLUMN_LOG_PART_NUMBER = "LOG_PART_NUMBER";
    public static final String COLUMN_LOG_PART_OPERATOR = "LOG_PART_OPERATOR";

    public static final String COLUMN_OUTCOME_LOG_PART = "OUTCOME_LOG_PART";

    public DataBaseHelper(@Nullable Context context) {
        super(context, "logPart.db", null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + LOG_PART_TABLE + " (" + COLUMN_JOB_NUMBER + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_LOG_PART_SERIAL + " TEXT, " + COLUMN_LOG_PART_NUMBER + " INT, " + COLUMN_LOG_PART_OPERATOR + " TEXT, " + COLUMN_OUTCOME_LOG_PART + " BOOL)";
        db.execSQL(createTableStatement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public boolean addOne(LogPartModel logPartModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_LOG_PART_SERIAL, logPartModel.getSerialNumber());
        cv.put(COLUMN_LOG_PART_NUMBER, logPartModel.getPartNumber());
        cv.put(COLUMN_LOG_PART_OPERATOR,logPartModel.getOperatorName());
        cv.put(COLUMN_OUTCOME_LOG_PART, logPartModel.isOutcome());
        long insert = db.insert(LOG_PART_TABLE, null, cv);
        return insert != -1;
    }

    public boolean deleteOne(LogPartModel logPartModel){
        SQLiteDatabase db = this.getWritableDatabase();
        String queryString = "DELETE FROM " + LOG_PART_TABLE + " WHERE " + COLUMN_JOB_NUMBER + " = " + logPartModel.getJobNumber();
        Cursor cursor = db.rawQuery(queryString, null);
        return cursor.moveToFirst();
    }
    public List<LogPartModel> getAllLogs(){
        List<LogPartModel> returnList = new ArrayList<>();

        String queryString = "SELECT * FROM " + LOG_PART_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()){
            do {
                int logPartJobNumber = cursor.getInt(0);
                String logPartNumber = cursor.getString(1);
                int logPartSerial = cursor.getInt(2);
                String logPartOperator = cursor.getString(3);
                boolean logPartOutcome = cursor.getInt(4) == 1 ? true : false;

                LogPartModel newLogPart = new LogPartModel(logPartJobNumber,logPartSerial ,logPartNumber , logPartOperator, logPartOutcome);
                returnList.add(newLogPart);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return returnList;
    }
}
