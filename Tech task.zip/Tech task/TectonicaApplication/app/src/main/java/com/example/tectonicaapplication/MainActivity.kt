package com.example.tectonicaapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    //reference to buttons and other controls on the layout
    private val dataBaseHelper = DataBaseHelper(this)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnAdd = findViewById<Button>(R.id.btn_add)
        val partName = findViewById<TextView>(R.id.editPartNumber)
        val serialNumber = findViewById<TextView>(R.id.editSerialNumber)
        val operator = findViewById<TextView>(R.id.editOperatorName)
        val outcome = findViewById<CheckBox>(R.id.testOutcome)
        val testList = findViewById<ListView>(R.id.lv_testList)

        showList(testList)

        btnAdd.setOnClickListener {
            val logPartModel : LogPartModel?
            try{
                logPartModel = LogPartModel(
                    -1,
                    Integer.parseInt(serialNumber.text.toString()),
                    partName.text.toString(),
                    operator.text.toString(),
                    outcome.isChecked
                )
                val dataBaseHelper = DataBaseHelper(this)

                val success = dataBaseHelper.addOne(logPartModel)

                Toast.makeText(this, "Success= $success", Toast.LENGTH_SHORT).show()
            }
            catch (e: Exception){
                Toast.makeText(this, "error creating log", Toast.LENGTH_SHORT).show()
            }

            showList(testList)
        }

        testList.setOnItemClickListener { parent, view, position, id ->
            val clickedCustomer = parent.getItemAtPosition(position) as LogPartModel
            dataBaseHelper.deleteOne(clickedCustomer)
            showList(testList)
        }

    }

    private fun showList(lvList: ListView) {
        val arrayAdapter = ArrayAdapter<LogPartModel>(
            this,
            android.R.layout.simple_list_item_1,
            dataBaseHelper.allLogs
        )
        lvList.adapter = arrayAdapter
    }
}